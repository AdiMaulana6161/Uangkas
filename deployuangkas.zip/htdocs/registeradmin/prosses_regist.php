<?php
require_once("../koneksi/conn.php");

		if(isset($_POST['login-submit'])){
            $name		= $_POST['name'];
			$username			= $_POST['username'];
            $passHash = password_hash($_POST ['password'],PASSWORD_DEFAULT);

            $cek = mysqli_query($conn, "SELECT * FROM tbl_user WHERE username='$username'") or die(mysqli_error($conn));
            if(mysqli_num_rows($cek) == 0){
				$sql = mysqli_query($conn, "INSERT INTO tbl_user(name,username, password) 
                VALUES('$name','$username', '$passHash')") or die(mysqli_error($conn));
				
				if($sql){
					echo '<script>alert("Selamat Anda Berhasil Mendaftar, Silahkan Login."); document.location="../auth/login.php";</script>';
				}else{
                    $error = true;
				}
			}else{
				$mail = true;
			}
		}
		?>

