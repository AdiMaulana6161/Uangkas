<?php
require_once('../koneksi/conn.php');
error_reporting(0);
session_start();
if(isset($_SESSION['user'])) {
  header('location: ../dashboardadmin.php');  
}

include '../helpers/Format.php';
$fm=new Format();

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
header("Cache-Control: max-age=2592000");
$errors = array();
if(isset($_POST['login-submit'])) { 
	  $username = $fm->validation($_POST['username']);
      $password = $fm->validation($_POST['password']);
      $user = $conn->real_escape_string($username);
      $pass = $conn->real_escape_string($password);

     if(empty($user) || empty($pass)) {
          if($user == "") {
            $errors[] = "Username Wajib di isi";
          } 
          if($pass == "") {
            $errors[] = "Password Wajib di isi";
          }
      }else {
      	$sql1 = $conn->query("SELECT username FROM tbl_user WHERE username = '$user'");
      	if ($sql1->num_rows > 0) {
      		$sql = $conn->query("SELECT password FROM tbl_user WHERE username = '$user'");
            $data = $sql->fetch_assoc();
            $hash = $data['password'];
            $pass1 = password_verify($pass,$hash);
             if($pass1){
                $sesi = $conn->query("SELECT * FROM tbl_user WHERE username='$user'");
                  $value = $sesi->fetch_assoc();
                  // set session
                  $_SESSION['user'] = $value['name'];
                  $_SESSION['id'] = $value['id'];
                  header('location: ../dashboardadmin.php');

                }else{
                   $errors[] = "Password Salah !";
                }
      	}else{
      		$errors[] = "Username tidak ditemukan !";
      	}

            

    }
} //tutup post
  
?>