<!DOCTYPE html>
<html lang="en">
<head>    
    <title>02TPLE01| 1 Dana Kas</title>
    <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Optional theme -->
	<link rel="stylesheet" href="assets/style_login.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
</head>

<body>
    <div class="container">
    	<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-login">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-12">
								<a href="#" class="active" id="login-form-link">Login Sebagai Admin Atau User</a><br>
								<a href="auth/login.php" class="active" id="login-form-link">Login Admin</a><br>
								<a href="loginuser/login.php" class="active" id="login-form-link">Login User</a><br>
							</div>
						</div>
						<hr>
					</div>
				</div>
			</div>
		</div>
	</div>
    <!-- jQuery -->
    <script src="../assets/pixeladmin-lite/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	    
</body>

</html>